# coronaverse VehicleUI NFive Plugin
[![License](https://img.shields.io/github/license/coronaverse/VehicleUI.svg)](LICENSE)
[![Build Status](https://img.shields.io/appveyor/ci/coronaverse/VehicleUI/master.svg)](https://ci.appveyor.com/project/coronaverse/VehicleUI)
[![Release Version](https://img.shields.io/github/release/coronaverse/VehicleUI/all.svg)](https://github.com/coronaverse/VehicleUI/releases)

Coronaverse Vehicle UI

## Installation
Install the plugin into your server from the [NFive Hub](https://hub.nfive.io/coronaverse/VehicleUI): `nfpm install coronaverse/VehicleUI`
